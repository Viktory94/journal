<!DOCTYPE html>
<html lang="ru">
<head>
 <meta charset="utf-8">
 <title>Главная</title>
 
<style type="text/css">
 
body, html {
		
	background: #263D83;
	text-align: center;
	color: white;
	margin: 10px;
}

p {
	margin: 10px;
}

input, textarea {
	
	
	border-radius: 10px;
	color: black;
	background: #9CB6AE;
	height: 30px;
	width: 400px;
	border-width: 0.2em;
	border-color: blue;
}

textarea {
	height: 70px;
}

.button {
	color: #00ADB6;
	width: 100px;
}

input[type="button"] {
	width: 200px; height: 40px;
}

input[type="reset"] {
	width: 200px; height: 40px;
}

</style>

</head>
<body>
	
 <?php include 'views/'.$content_view;?>
 
</body>
</html> 